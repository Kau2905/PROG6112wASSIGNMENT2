/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.kauranmunienprog1bassignment2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kau29
 */
public class KauranMunienProg1BAssignment2IT {

    private RescueManager manager;
    private InjuredAnimalRescue injuredCase;
    private OrphanedAnimalRescue orphanedCase;
    private EndangeredSpeciesRescue endangeredCase;

    @BeforeEach
    void setUp() {
        manager = new RescueManager();

        // Sample concrete instances for testing
        // Days: 5, Daily Cost: 100.00 -> Base Cost = 500.00
        // Vet Cost: 2000.00, Surgery: true (+5000.00) -> Total = 7500.00
        injuredCase = new InjuredAnimalRescue(
                "RES-001", "Leo", "Lion", "Kruger National Park",
                "Ranger Smith", 5, 100.0,
                "Fractured Leg", 2000.0, true
        );

        // Days: 10, Daily Cost: 50.00 -> Base Cost = 500.00
        // Age: 2 months, Feeding: 300.00, Foster Care: true (+2500.00) -> Total = 3300.00
        orphanedCase = new OrphanedAnimalRescue(
                "RES-002", "Bella", "Rhino", "Pilanesberg",
                "Ranger Dave", 10, 50.0,
                2, 300.0, true
        );

        // Days: 4, Daily Cost: 200.00 -> Base Cost = 800.00
        // Security: 1500.00, Specialist Team: false -> Total = 2300.00
        endangeredCase = new EndangeredSpeciesRescue(
                "RES-003", "Chester", "Cheetah", "Karoo",
                "Ranger Sarah", 4, 200.0,
                "Vulnerable", 1500.0, false
        );
    }

    // -------------------------------------------------------------------------
    // 1. Rescue Cost Calculations
    // -------------------------------------------------------------------------
    @Test
    @DisplayName("Verify Rescue Cost Calculations across different rescue types")
    void testRescueCostCalculations() {
        // Injured Animal: (5 * 100) + 2000 + 5000 = 7500.00
        assertEquals(7500.00, injuredCase.calculateTotalCost(), 0.001,
                "Injured animal cost calculation incorrect.");

        // Orphaned Animal: (10 * 50) + 300 + 2500 = 3300.00
        assertEquals(3300.00, orphanedCase.calculateTotalCost(), 0.001,
                "Orphaned animal cost calculation incorrect.");

        // Endangered Species: (4 * 200) + 1500 = 2300.00
        assertEquals(2300.00, endangeredCase.calculateTotalCost(), 0.001,
                "Endangered species cost calculation incorrect.");
    }

    // -------------------------------------------------------------------------
    // 2. Rescue Priority Calculations
    // -------------------------------------------------------------------------
    @Test
    @DisplayName("Verify Rescue Priority Calculations")
    void testRescuePriorityCalculations() {
        // Surgery required = CRITICAL
        assertEquals(RescuePriority.CRITICAL, injuredCase.determinePriority(),
                "Priority should be CRITICAL when surgery is required.");

        // Age <= 3 months = HIGH
        assertEquals(RescuePriority.HIGH, orphanedCase.determinePriority(),
                "Priority should be HIGH for orphaned animals 3 months or younger.");

        // Classification 'Vulnerable' and no specialist team = HIGH
        assertEquals(RescuePriority.HIGH, endangeredCase.determinePriority(),
                "Priority should default to HIGH for endangered species.");
    }

    // -------------------------------------------------------------------------
    // 3. Rescue Status Updates
    // -------------------------------------------------------------------------
    @Test
    @DisplayName("Verify Rescue Status Updates via RescueManager and state transitions")
    void testRescueStatusUpdates() {
        manager.addCase(injuredCase);

        // Initial status should be REPORTED
        assertEquals(RescueStatus.REPORTED, injuredCase.getStatus());

        // Update using RescueManager
        boolean updated = manager.updateStatus("RES-001", RescueStatus.IN_PROGRESS);
        assertTrue(updated, "updateStatus should return true for an existing case.");
        assertEquals(RescueStatus.IN_PROGRESS, injuredCase.getStatus(),
                "Status should update to IN_PROGRESS.");

        // Direct state change using method transition
        injuredCase.completeRescue();
        assertEquals(RescueStatus.COMPLETED, injuredCase.getStatus(),
                "Status should transition to COMPLETED via completeRescue().");
    }

    // -------------------------------------------------------------------------
    // 4. Searching for an Existing Rescue Case
    // -------------------------------------------------------------------------
    @Test
    @DisplayName("Verify Searching for an Existing Rescue Case by ID")
    void testSearchExistingRescueCase() {
        manager.addCase(injuredCase);
        manager.addCase(orphanedCase);

        // Search for existing ID (case-insensitive check)
        RescueCase foundCase = manager.findById("res-001");
        assertNotNull(foundCase, "Search result should not be null for an existing ID.");
        assertEquals("RES-001", foundCase.getCaseId(), "Returned Case ID should match searched ID.");

        // Search for non-existent ID
        RescueCase notFound = manager.findById("RES-999");
        assertNull(notFound, "Search result should be null for a non-existent ID.");
    }

    // -------------------------------------------------------------------------
    // 5. Preventing Duplicate Rescue Case IDs
    // -------------------------------------------------------------------------
    @Test
    @DisplayName("Verify Duplicate Rescue Case IDs are prevented")
    void testPreventingDuplicateRescueCaseIDs() {
        manager.addCase(injuredCase);

        // Attempting to add another case with the same ID "RES-001"
        InjuredAnimalRescue duplicateCase = new InjuredAnimalRescue(
                "RES-001", "Shadow", "Panther", "Kruger",
                "Ranger Alex", 2, 150.0,
                "Minor cuts", 500.0, false
        );

        // Verify that adding a duplicate throws an IllegalArgumentException
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            manager.addCase(duplicateCase);
        }, "Adding a duplicate Case ID must throw an IllegalArgumentException.");

        assertEquals("Rescue Case ID 'RES-001' already exists.", exception.getMessage());
    }

    // -------------------------------------------------------------------------
    // 6. Validation Verification (Zero/Blank checks & continuous running)
    // -------------------------------------------------------------------------
    @Test
    @DisplayName("Verify invalid inputs throw exceptions without crashing overall execution")
    void testInvalidInputsAndValidation() {
        // Blank assigned ranger
        assertThrows(IllegalArgumentException.class, () -> {
            new InjuredAnimalRescue("RES-010", "Simba", "Lion", "Kruger", "", 5, 100.0, "Cut", 500.0, false);
        }, "Blank ranger name must throw an IllegalArgumentException.");

        // Non-positive rescue days (zero or negative)
        assertThrows(IllegalArgumentException.class, () -> {
            new OrphanedAnimalRescue("RES-011", "Milo", "Otter", "River", "Ranger Dave", 0, 100.0, 2, 200.0, false);
        }, "Rescue days of zero or less must throw an IllegalArgumentException.");

        // Non-positive daily care cost
        assertThrows(IllegalArgumentException.class, () -> {
            new EndangeredSpeciesRescue("RES-012", "Luna", "Leopard", "Forest", "Ranger Sarah", 3, -50.0, "Endangered", 1000.0, false);
        }, "Daily care cost of zero or less must throw an IllegalArgumentException.");
    }
}
