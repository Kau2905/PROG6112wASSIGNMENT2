/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.kauranmunienprog1bassignment2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kau29
 */
public class RescuableIT {
    
    public RescuableIT() {
    }

    @Test
    public void testStartRescue() {
    }

    @Test
    public void testCompleteRescue() {
    }

    @Test
    public void testGenerateSummary() {
    }

    public class RescuableImpl implements Rescuable {

        public void startRescue() {
        }

        public void completeRescue() {
        }

        public String generateSummary() {
            return "";
        }
    }
    
}
