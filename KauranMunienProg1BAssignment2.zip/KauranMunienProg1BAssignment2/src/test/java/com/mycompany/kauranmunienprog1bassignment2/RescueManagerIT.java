/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.kauranmunienprog1bassignment2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kau29
 */
public class RescueManagerIT {
    
    public RescueManagerIT() {
    }

    @Test
    public void testAddCase() {
    }

    @Test
    public void testIdExists() {
    }

    @Test
    public void testFindById() {
    }

    @Test
    public void testUpdateStatus() {
    }

    @Test
    public void testGetAllCases() {
    }

    @Test
    public void testGetCaseCount() {
    }

    @Test
    public void testGetTotalEstimatedCost() {
    }

    @Test
    public void testGenerateReport() {
    }
    
}
