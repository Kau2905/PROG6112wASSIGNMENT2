/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.kauranmunienprog1bassignment2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kau29
 */
public class RescueCaseIT {
    
    public RescueCaseIT() {
    }

    @Test
    public void testGetRescueType() {
    }

    @Test
    public void testDeterminePriority() {
    }

    @Test
    public void testGetSpecificDetails() {
    }

    @Test
    public void testCalculateTotalCost() {
    }

    @Test
    public void testStartRescue() {
    }

    @Test
    public void testCompleteRescue() {
    }

    @Test
    public void testGenerateSummary() {
    }

    @Test
    public void testFormatMoney() {
    }

    @Test
    public void testGetCaseId() {
    }

    @Test
    public void testGetAnimalName() {
    }

    @Test
    public void testGetSpecies() {
    }

    @Test
    public void testGetLocation() {
    }

    @Test
    public void testGetRanger() {
    }

    @Test
    public void testGetRescueDays() {
    }

    @Test
    public void testGetDailyCareCost() {
    }

    @Test
    public void testGetStatus() {
    }

    @Test
    public void testSetStatus() {
    }

    @Test
    public void testToString() {
    }

    public class RescueCaseImpl extends RescueCase {

        public RescueCaseImpl() {
            super("", "", "", "", "", 0, 0.0);
        }

        public String getRescueType() {
            return "";
        }

        public double calculateAdditionalCost() {
            return 0.0;
        }

        public RescuePriority determinePriority() {
            return null;
        }

        public String getSpecificDetails() {
            return "";
        }
    }
    
}
