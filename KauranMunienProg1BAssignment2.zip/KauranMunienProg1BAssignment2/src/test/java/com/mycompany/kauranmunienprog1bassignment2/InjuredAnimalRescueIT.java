/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.kauranmunienprog1bassignment2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kau29
 */
public class InjuredAnimalRescueIT {
    
    public InjuredAnimalRescueIT() {
    }

    @Test
    public void testGetRescueType() {
    }

    @Test
    public void testDeterminePriority() {
    }

    @Test
    public void testGetSpecificDetails() {
    }

    @Test
    public void testGetInjuryDescription() {
    }

    @Test
    public void testGetVeterinaryCost() {
    }

    @Test
    public void testIsSurgeryRequired() {
    }
    
}
